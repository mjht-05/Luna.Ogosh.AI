langs = '''Afrikaans
Albanian
Amharic
Arabic
Armenian
Assamese
Aymara
Azerbaijani
Bambara
Basque
Belarusian
Bengali
Bhojpuri
Bosnian
Bulgarian
Catalan
Cebuano
Chinese (Simplified)
Chinese (Traditional)
Corsican
Croatian
Czech
Danish
Dhivehi
Dogri
Dutch
English
Esperanto
Estonian
Ewe
Filipino
Finnish
French
Frisian
Galician
Georgian
German
Greek
Guarani
Gujarati
Haitian Creole
Hausa
Hawaiian
Hebrew
Hindi
Hmong
Hungarian
Icelandic
Igbo
Ilocano
Indonesian
Irish
Italian
Japanese
Javanese
Kannada
Kazakh
Khmer
Kinyarwanda
Konkani
Korean
Krio
Kurdish (Kurmanji)
Kurdish (Sorani)
Kyrgyz
Lao
Latin
Latvian
Lingala
Lithuanian
Luganda
Luxembourgish
Macedonian
Maithili
Malagasy
Malay
Malayalam
Maltese
Maori
Marathi
Meiteilon (Manipuri)
Mizo
Mongolian
Myanmar (Burmese)
Nepali
Norwegian
Nyanja (Chichewa)
Odia (Oriya)
Oromo
Pashto
Persian
Polish
Portuguese
Punjabi
Quechua
Romanian
Russian
Samoan
Sanskrit
Scots Gaelic
Sepedi
Serbian
Sesotho
Shona
Sindhi
Sinhala
Slovak
Slovenian
Somali
Spanish
Sundanese
Swahili
Swedish
Tajik
Tamil
Tatar
Telugu
Thai
Tigrinya
Tsonga
Turkish
Turkmen
Twi (Akan)
Ukrainian
Urdu
Uyghur
Uzbek
Vietnamese
Welsh
Xhosa
Yiddish
Yoruba
Zulu'''.split('\n')

codes = {
'Afrikaans':'af', 'Albanian':'sq', 'Amharic':'am', 'Arabic':'ar', 'Armenian':'hy',
'Assamese':'as', 'Aymara':'ay', 'Azerbaijani':'az', 'Bambara':'bm', 'Basque':'eu',
'Belarusian':'be', 'Bengali':'bn', 'Bhojpuri':'bho', 'Bosnian':'bs', 'Bulgarian':'bg',
'Catalan':'ca', 'Cebuano':'ceb', 'Chinese (Simplified)':'zh-CN', 'Chinese (Traditional)':'zh-TW',
'Corsican':'co', 'Croatian':'hr', 'Czech':'cs', 'Danish':'da', 'Dhivehi':'dv',
'Dogri':'doi', 'Dutch':'nl', 'English':'en', 'Esperanto':'eo', 'Estonian':'et',
'Ewe':'ee', 'Filipino':'tl', 'Finnish':'fi', 'French':'fr', 'Frisian':'fy',
'Galician':'gl', 'Georgian':'ka', 'German':'de', 'Greek':'el', 'Guarani':'gn',
'Gujarati':'gu', 'Haitian Creole':'ht', 'Hausa':'ha', 'Hawaiian':'haw', 'Hebrew':'he',
'Hindi':'hi', 'Hmong':'hmn', 'Hungarian':'hu', 'Icelandic':'is', 'Igbo':'ig',
'Ilocano':'ilo', 'Indonesian':'id', 'Irish':'ga', 'Italian':'it', 'Japanese':'ja',
'Javanese':'jv', 'Kannada':'kn', 'Kazakh':'kk', 'Khmer':'km', 'Kinyarwanda':'rw',
'Konkani':'gom', 'Korean':'ko', 'Krio':'kri', 'Kurdish (Kurmanji)':'ku', 'Kurdish (Sorani)':'ckb',
'Kyrgyz':'ky', 'Lao':'lo', 'Latin':'la', 'Latvian':'lv', 'Lingala':'ln',
'Lithuanian':'lt', 'Luganda':'lg', 'Luxembourgish':'lb', 'Macedonian':'mk', 'Maithili':'mai',
'Malagasy':'mg', 'Malay':'ms', 'Malayalam':'ml', 'Maltese':'mt', 'Maori':'mi',
'Marathi':'mr', 'Meiteilon (Manipuri)':'mni-Mtei', 'Mizo':'lus', 'Mongolian':'mn', 'Myanmar (Burmese)':'my',
'Nepali':'ne', 'Norwegian':'no', 'Nyanja (Chichewa)':'ny', 'Odia (Oriya)':'or', 'Oromo':'om',
'Pashto':'ps', 'Persian':'fa', 'Polish':'pl', 'Portuguese':'pt', 'Punjabi':'pa',
'Quechua':'qu', 'Romanian':'ro', 'Russian':'ru', 'Samoan':'sm', 'Sanskrit':'sa',
'Scots Gaelic':'gd', 'Sepedi':'nso', 'Serbian':'sr', 'Sesotho':'st', 'Shona':'sn',
'Sindhi':'sd', 'Sinhala':'si', 'Slovak':'sk', 'Slovenian':'sl', 'Somali':'so',
'Spanish':'es', 'Sundanese':'su', 'Swahili':'sw', 'Swedish':'sv', 'Tajik':'tg',
'Tamil':'ta', 'Tatar':'tt', 'Telugu':'te', 'Thai':'th', 'Tigrinya':'ti',
'Tsonga':'ts', 'Turkish':'tr', 'Turkmen':'tk', 'Twi (Akan)':'ak', 'Ukrainian':'uk',
'Urdu':'ur', 'Uyghur':'ug', 'Uzbek':'uz', 'Vietnamese':'vi', 'Welsh':'cy',
'Xhosa':'xh', 'Yiddish':'yi', 'Yoruba':'yo', 'Zulu':'zu'
}

lines = []
for lang in langs:
    if lang:
        key = lang.lower().replace(' ', '_').replace('(', '').replace(')', '')
        code = codes.get(lang, '')
        lines.append(f"  {key}: {{ label: '{lang}', code: '{code}' }},")

lines.append("  hinglish: { label: 'Hinglish (HiEn)', code: 'hien' }")

print('const ALL_LANGS = {\n' + '\n'.join(lines) + '\n};')
